import React from 'react';
import logo from './logo.svg';
import Card from './components/Card';
import './App.css';

function App() {
  return (
    <div className="App">
        <Card image={'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a7/React-icon.svg/1200px-React-icon.svg.png'} text={'oi'}></Card>
    </div>
  );
}

export default App;
